from django.contrib import admin
from chat.models import ChatRoom

admin.site.register(ChatRoom)
